 %%  figure 9
syms V_in V_out V_B V_A V_k R Cs R3 R4
eq1 = (V_B - V_in)/(2*R) + (V_B - V_out)/(2*R) + (V_B - V_k)*2*Cs == 0;
eq2 = (V_A - V_in)*Cs + (V_A - V_out)*Cs + (V_A - V_k)/R == 0;
eq3 = V_k/R4 + (V_k - V_out)/R3 + (V_k - V_B)*2*Cs + (V_k - V_A)/R == 0;
eq4 = (V_out - V_k)/R3 + (V_out - V_A)*Cs + (V_out - V_B)/(2*R) == 0;

vars = [V_out, V_k, V_A, V_B];
eqs = [eq1; eq2; eq3; eq4];
[A, B] = equationsToMatrix(eqs, vars);

solutions = A \ B;
H_s = simplify(solutions(1) / V_in);

disp('H(s) = V_out / V_in:')
disp(H_s);
%% figure 10 
syms V_in V_out V_B V_A  R1 R2 R3 R4 C1 C2 C3 s

eq1 = (V_A - V_in)*C2*s + (V_A)/(R4) + (V_A - V_B)/(R1)+(V_A-V_out)*C3*s == 0;
eq2 = (V_B - V_A)/(R1) + (V_B)*C1*s + (V_B - V_out)/(R2) == 0;
eq3 = V_out/R3 + (V_out - V_A)*C3*s + (V_out - V_B)/(R2)  == 0;

vars = [V_out, V_A, V_B];
eqs = [eq1; eq2; eq3;];
[A, B] = equationsToMatrix(eqs, vars);
solutions = A \ B;

H_s = simplify(solutions(1) / V_in);
disp('H(s) = V_out / V_in:')
disp(H_s);
