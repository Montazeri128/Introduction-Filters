%%
clc
clear
close all
%% طراحی فیلترهای مورد نیاز
H_highpass = designfilt('highpassiir', 'FilterOrder', 10, 'HalfPowerFrequency', 0.35);
H_lowpass = designfilt('lowpassiir', 'FilterOrder', 10, 'HalfPowerFrequency', 0.25);
lower_cutoff = 0.35;
upper_cutoff = 0.9;
H_bandpass = designfilt('bandpassiir', 'FilterOrder', 10, 'HalfPowerFrequency1', lower_cutoff, 'HalfPowerFrequency2', upper_cutoff);

%% بارگذاری فایل‌های صوتی
[y, Fs] = audioread('audio1_cut.wav');
[y2, ] = audioread('audio2_cut.wav');

%% افزایش نرخ نمونه‌برداری
upsample_factor = 4;
y_upsampled = interp(y, upsample_factor);
y_upsampled2 = interp(y2, upsample_factor);
Fs_upsampled = Fs * upsample_factor;

%% اضافه کردن موج کسینوسی
numSamples = length(y_upsampled2);
frequency = 500;
amplitude = 7;
t = (0:numSamples-1) / Fs_upsampled;
y_upsampled2 = y_upsampled2 + amplitude * cos(2 * pi * frequency * t');

%% مدولاسیون سیگنال
N_upsampled = length(y_upsampled);
t_upsampled = (0:N_upsampled-1) / Fs_upsampled;
w = 2 * pi * 12000;
y_cos = y_upsampled .* cos(w * t_upsampled');
y_cos = filter(H_highpass, y_cos);

y_sum = y_cos + y_upsampled2;

audiowrite('C:\\Users\\Nafis Rayaneh\\Desktop\\output_signalsum.wav', y_sum, Fs_upsampled);

%% اعمال فیلترها
y_notch = filter(designfilt('bandstopiir', 'FilterOrder', 14, 'HalfPowerFrequency1', 450, 'HalfPowerFrequency2', 470, 'SampleRate', Fs_upsampled), y_sum);
y_lowpass = filter(H_lowpass, y_notch);
y_bandpass = filter(H_bandpass, y_notch);

y_final = 5 * y_bandpass .* cos(w * t_upsampled');
y_output = filter(H_lowpass, y_final);

%% ذخیره فایل‌های خروجی
audiowrite('C:\\Users\\Nafis Rayaneh\\Desktop\\output_signal1.wav', y_output, Fs_upsampled);
audiowrite('C:\\Users\\Nafis Rayaneh\\Desktop\\output_signal2.wav', y_lowpass, Fs_upsampled);

audiowrite('C:\\Users\\Nafis Rayaneh\\Desktop\\output_signalsum.wav', y_sum, Fs_upsampled);

%% پخش صدای ترکیب شده
sound(y_sum, Fs_upsampled);

%% آماده‌سازی خروجی‌ها برای Simulink
tosim1 = timeseries(y_output, t_upsampled);
tosim2 = timeseries(y_lowpass, t_upsampled);

%% خروجی‌های Simulink
time = out.tout;
signal1 = out.simout1.Data;
signal2 = out.simout2.Data;

%% ذخیره فایل‌های خروجی Simulink
audiowrite('C:\\Users\\Nafis Rayaneh\\Desktop\\output_signalsum_simulink1.wav', signal1, Fs_upsampled);
audiowrite('C:\\Users\\Nafis Rayaneh\\Desktop\\output_signalsum_simulink2.wav', signal2, Fs_upsampled);
